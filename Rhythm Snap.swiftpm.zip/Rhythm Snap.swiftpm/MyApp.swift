import SwiftUI

@main
struct MyApp: App {
    @StateObject public var bpmTracker = BpmTracker()


    
    var body: some Scene {
        WindowGroup {
            OnboardingView()
                .environmentObject(bpmTracker)
        }
    }
}
